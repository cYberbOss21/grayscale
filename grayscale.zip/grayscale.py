import os
import numpy as np
from math import sqrt, ceil
import cv2

def generate_grayscale_images(folder_path):
    # Create a new folder to store the grayscale images
    output_folder = os.path.join(folder_path, 'Grayscale_Images')
    os.makedirs(output_folder, exist_ok=True)

    # Get a list of all ".exe" files in the folder
    exe_files = [file for file in os.listdir(folder_path) if file.endswith('.exe')]

    for exe_file in exe_files:
        # Read the executable file as binary and get the data
        with open(os.path.join(folder_path, exe_file), 'rb') as binary_file:
            data = binary_file.read()

        # Data length in bytes
        data_len = len(data)

        # Convert the data into a numpy array of uint8
        d = np.frombuffer(data, dtype=np.uint8)

        # Assume image shape should be close to square
        sqrt_len = int(ceil(sqrt(data_len)))  # Compute square root and round up

        # Required length in bytes
        new_len = sqrt_len * sqrt_len

        # Number of bytes to pad (need to add zeros to the end of d)
        pad_len = new_len - data_len

        # Pad d with zeros at the end
        padded_d = np.hstack((d, np.zeros(pad_len, np.uint8)))

        # Reshape 1D array into 2D array with shape (sqrt_len, sqrt_len)
        im = np.reshape(padded_d, (sqrt_len, sqrt_len))

        # Save the grayscale image
        image_path = os.path.join(output_folder, os.path.splitext(exe_file)[0] + '.png')
        cv2.imwrite(image_path, im)
        print(f"Grayscale image generated for {exe_file} at {image_path}")

# Specify the folder path where the ".exe" files are located
folder_path = '/home/cyberboss/Downloads/altered/'

# Generate grayscale images for the ".exe" files in the specified folder
generate_grayscale_images(folder_path)
